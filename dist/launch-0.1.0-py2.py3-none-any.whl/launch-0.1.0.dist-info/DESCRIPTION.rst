Microsoft Azure CLI 'launch' Extension


